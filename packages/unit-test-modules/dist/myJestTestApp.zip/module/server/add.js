if (typeof define !== 'function') {
  var define = require('../../define-shim').define(module);
}

define(function (require) {
  'use strict';

  return {
    add: function add(a, b) {
      return a + b;
    }
  };
});