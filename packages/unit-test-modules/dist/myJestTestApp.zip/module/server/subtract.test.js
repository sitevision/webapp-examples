var _require = require('./subtract'),
    subtract = _require.subtract;

describe('subtract', function () {
  it('can subtract numbers', function () {
    expect(subtract(3, 2)).toBe(1);
  });
});