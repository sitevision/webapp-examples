var _require = require('./math'),
    add = _require.add,
    subtract = _require.subtract;

describe('math', function () {
  it('can subtract numbers', function () {
    expect(subtract(3, 2)).toBe(1);
  });
  it('can add numbers', function () {
    expect(add(3, 2)).toBe(5);
  });
});