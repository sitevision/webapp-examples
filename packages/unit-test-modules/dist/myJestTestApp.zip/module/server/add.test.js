var _require = require('./add'),
    add = _require.add;

describe('simple-module', function () {
  it('can add numbers', function () {
    expect(add(1, 3)).toBe(4);
  });
});