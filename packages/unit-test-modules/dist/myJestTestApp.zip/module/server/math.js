if (typeof define !== 'function') {
  var define = require('../../define-shim').define(module);
}

define(function (require) {
  'use strict';

  var _require = require('/module/server/add'),
      add = _require.add;

  var _require2 = require('/module/server/subtract'),
      subtract = _require2.subtract;

  return {
    add: add,
    subtract: subtract
  };
});