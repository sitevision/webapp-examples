module.exports.define = function (module) {
  return require('amdefine')(module, function (requirePath) {
    var modifiedPath;

    if (requirePath.charAt(0) === '/') {
      var path = require('path');

      modifiedPath = './' + path.relative(__dirname, path.join('src', requirePath));
    } else {
      modifiedPath = requirePath;
    }

    return require(modifiedPath);
  });
};