(function () {
  'use strict';

  var router = require('router');

  var appData = require('appData');

  var _require = require('/module/server/add'),
      add = _require.add;

  router.get('/', function (req, res) {
    var message = 'Hello, world!';
    var name = appData.get('name');
    res.render('/', {
      message: message,
      name: name,
      result: add(3, 7)
    });
  });
})();