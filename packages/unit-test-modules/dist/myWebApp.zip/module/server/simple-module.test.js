var test = require('./simple-module');

describe('simple-module', function () {
  it('can add numbers', function () {
    expect(test.add(1, 3)).toBe(4);
  });
});