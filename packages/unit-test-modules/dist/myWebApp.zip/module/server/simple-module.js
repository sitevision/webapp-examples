define(function (require) {
  var test = {
    add: function add(a, b) {
      return a + b;
    }
  };

  if (process && process.env.NODE_ENV === 'test') {
    module.exports = test;
  }

  return test;
});